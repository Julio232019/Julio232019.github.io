from textx import metamodel_from_file

# Car class definition
class Car:
    def __init__(self, name, model, color, max_speed, fuel, engine_status):
        self.name = name
        self.model = model
        self.color = color
        self.max_speed = max_speed
        self.fuel = fuel
        self.engine_status = engine_status
        self.speed = 0

    def __str__(self):
        return f"{self.name} - {self.model}, Speed: {self.speed} km/h, Fuel: {self.fuel}%"

    def accelerate(self, amount):
        if self.fuel > 0:
            self.speed += amount
            self.fuel -= amount * 0.1
            print(f"{self.name} accelerates by {amount} km/h.")
        else:
            print(f"{self.name} is out of fuel!")

    def drive(self, direction, distance):
        if self.fuel > 0:
            self.speed = distance
            self.fuel -= distance * 0.05
            print(f"{self.name} is driving {direction} for {distance} km at {self.speed} km/h.")
        else:
            print(f"{self.name} is out of fuel!")

    def turn(self, direction, degrees):
        print(f"{self.name} turned {direction} by {degrees} degrees.")

    def stop(self):
        self.speed = 0
        print(f"{self.name} has stopped.")

    def check_status(self, status_type):
        if status_type == "fuel":
            print(f"{self.name}'s fuel: {self.fuel}%")
        elif status_type == "speed":
            print(f"{self.name}'s speed: {self.speed} km/h")
        elif status_type == "engine_status":
            print(f"{self.name}'s engine status: {self.engine_status}")

# Define the metamodel and interpret the commands
def interpret(model):
    cars = {}

    for c in model.commands:
        if c.__class__.__name__ == "CarDefinition":
            car = Car(
                c.name, 
                c.model, 
                c.color, 
                c.max_speed, 
                c.fuel, 
                c.engine_status
            )
            cars[c.name] = car
            print(f"Created car: {car}")

        elif c.__class__.__name__ == "MoveCommand":
            
            if c.direction == "forward":
                car.drive('forward', c.distance)
            elif c.direction == "backward":
                car.drive('backward', c.distance)
            elif c.direction == "left":
                car.turn('left', c.distance)
            elif c.direction == "right":
                car.turn('right', c.distance)

        elif c.__class__.__name__ == "AccelerateCommand":
            
            car.accelerate(c.amount)

        elif c.__class__.__name__ == "CheckStatusCommand":
            
            car.check_status(c.status_type)

        else:
            print(f"Unknown command: {c}")

# Load the metamodel from the tx file
car_mm = metamodel_from_file('ProjectDrive.tx')

# Load the model from the DSL example file (e.g., example1.drive)
car_model = car_mm.model_from_file('example1.drive')

# Interpret the commands from the model
interpret(car_model)
