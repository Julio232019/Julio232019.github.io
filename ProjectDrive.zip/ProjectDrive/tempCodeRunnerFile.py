from textx import metamodel_from_file

car_mm = metamodel_from_file('ProjectDrive.tx')
car_model = car_mm.model_from_file('example1.drive')

class Car:
    def __init__(self, name, model, color, max_speed, fuel, engine_status):
        self.name = name
        self.model = model
        self.color = color
        self.max_speed = max_speed
        self.fuel = fuel
        self.engine_status = engine_status
        self.speed = 0

    def __str__(self):
        return f"{self.name} - {self.model}, Speed: {self.speed} km/h, Fuel: {self.fuel}%"

    def accelerate(self, amount):
        if self.fuel > 0:
            self.speed += amount
            self.fuel -= amount * 0.1
            print(f"{self.name} accelerates by {amount} km/h.")
        else:
            print(f"{self.name} is out of fuel!")

    def drive(self, direction, distance):
        if self.fuel > 0:
            self.speed = distance
            self.fuel -= distance * 0.05
            print(f"{self.name} is driving {direction} for {distance} km at {self.speed} km/h.")
        else:
            print(f"{self.name} is out of fuel!")

    def turn(self, direction, degrees):
        print(f"{self.name} turned {direction} by {degrees} degrees.")

    def stop(self):
        self.speed = 0
        print(f"{self.name} has stopped.")

    def check_status(self, status_type):
        if status_type == "fuel":
            print(f"{self.name}'s fuel: {self.fuel}%")
        elif status_type == "speed":
            print(f"{self.name}'s speed: {self.speed} km/h")
        elif status_type == "engine_status":
            print(f"{self.name}'s engine status: {self.engine_status}")

# Create the metamodel using the grammar (auto_script.tx)


def interpret(model):
    cars = {}

    for cmd in model.commands:
        if isinstance(cmd, CarDefinition):
            car = Car(
                cmd.name, 
                cmd.model, 
                cmd.color, 
                cmd.max_speed, 
                cmd.fuel, 
                cmd.engine_status
            )
            cars[cmd.name] = car
            print(f"Created car: {car}")

        elif isinstance(cmd, MoveCommand):
            car = cars.get(cmd.car)
            if cmd.direction == "forward":
                car.drive('forward', cmd.distance)
            elif cmd.direction == "backward":
                car.drive('backward', cmd.distance)
            elif cmd.direction == "left":
                car.turn('left', cmd.distance)
            elif cmd.direction == "right":
                car.turn('right', cmd.distance)

        elif isinstance(cmd, SimulateCommand):
            car = cars.get(cmd.car)
            print(f"Simulating {cmd.car} for {cmd.time} minutes.")
            for action in cmd.actions:
                if action.direction == "forward":
                    car.drive('forward', action.distance)
                elif action.direction == "backward":
                    car.drive('backward', action.distance)
                elif action.direction == "left":
                    car.turn('left', action.distance)
                elif action.direction == "right":
                    car.turn('right', action.distance)
            print(f"Simulation for {cmd.car} has ended!\n")
        
        elif isinstance(cmd, SimulationEnd):
            # Simulation has ended, print a final message.
            print("Simulation has ended. Continuing with other commands...\n")

        else:
            print(f"Unknown command: {cmd}")

# Example AutoScript DSL code with simulate and simulation end commands

car = Car()

car.interpret(car_model)

